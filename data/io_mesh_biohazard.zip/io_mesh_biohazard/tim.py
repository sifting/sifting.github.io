import bpy
from struct import unpack

def decode (data):
	def torgba (c):
		#Extract colour coordinates
		stp = ((c>>15)&0x1)
		b = ((c>>10)&0x1f)
		g = ((c>>5)&0x1f)
		r = (c&0x1f)
		#Black is always transparent unless the stp bit is set, lol.
		if 0 == (r|g|b):
			if stp: a = 1
			else: a = 0
		else:
			a = 1
		#Convert to floating point
		return [r/31, g/31, b/31, a/1]
	#Constants
	FOURBIT_THUG = 8
	EIGHTBIT_THUG = 9
	SIXTEENBIT_THUG = 2
	#Ensure this magic is correct
	_data = data
	h = unpack ("<3L4H", data[:20])
	data = data[20:]
	print (h)
	if h[0] != 0x10:
		raise ValueError ("Invalid TIM")
	#Ensure image is a valid type
	if h[1] != FOURBIT_THUG and h[1] != EIGHTBIT_THUG and h[1] != SIXTEENBIT_THUG:
		raise ValueError ("Invalid image type")
	#Extract palettes
	palettes = []
	if h[1] == FOURBIT_THUG or h[1] == EIGHTBIT_THUG:
		ncol = h[5]
		npal = h[6]
		for i in range (npal):
			pal = []
			for k in range (ncol):
				c = unpack ("<H", data[:2])
				data = data[2:]
				pal.append (torgba (c[0]))
			palettes.append (pal)
		print ("PALS {0}".format (len (palettes)))
	#Extract image size
	length = unpack ("<L", data[:4])
	data = data[4:]
	print (length)
	xy = unpack ("<2H", data[:4])
	print (xy)
	data = data[4:]
	size = unpack ("<2H", data[:4])
	print (size)
	data = data[4:]
	#Convert image
	pixels = []
	if h[1] == FOURBIT_THUG:
		width = 4*size[0]
		for y in range (size[1]):
			row = []
			for x in range (size[0]):
				if len (palettes) == 2:
					if x < size[0]/2: pal = palettes[0]
					else: pal = palettes[1]
				w = unpack ("<H", data[:2])[0]
				data = data[2:]
				id1 = (w>>12)&0xf
				id2 = (w>>8)&0xf
				id3 = (w>>4)&0xf
				id4 = w&0xf
				row.append (pal[id4])
				row.append (pal[id3])
				row.append (pal[id2])
				row.append (pal[id1])
			pixels.insert (0, row)
	elif h[1] == EIGHTBIT_THUG:
		width = 2*size[0]
		for y in range (size[1]):
			row = []
			for x in range (size[0]):
				if len (palettes) == 2:
					if x < size[0]/2: pal = palettes[0]
					else: pal = palettes[1]
				w = unpack ("<H", data[:2])[0]
				data = data[2:]
				id1 = (w>>8)&0xff
				id2 = w&0xff
				row.append (pal[id2])
				row.append (pal[id1])
			pixels.insert (0, row)
	else: #16 bit images
		width = size[0]
		for y in range (size[1]):
			row = []
			for x in range (size[0]):
				if len (palettes) == 2:
					if x < size[0]/2: pal = palettes[0]
					else: pal = palettes[1]
				w = unpack ("<H", data[:2])[0]
				data = data[2:]
				row.append (torgba (w))
			pixels.insert (0, row)
	#Create the image
	print (width, size[1])
	image = bpy.data.images.new ("TIM", width, size[1], alpha = 1)
	image.pixels = [z for y in pixels for x in y for z in x]
	image.pack (as_png = True)
	return image