# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation, either version 3
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#  All rights reserved.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
	"name": "Biohazard importer",
	"author": "Sifting",
	"version": (1, 0, 0),
	"blender": (2, 78, 0),
	"location": "File > Import > Biohazard",
	"description": "Imports models from Biohazard",
	"wiki_url": "",
	"category": "Import-Export"}


import bpy
from bpy.props import BoolProperty
from bpy.props import FloatProperty
from bpy.props import StringProperty
from bpy.props import EnumProperty

class ImportBiohazard(bpy.types.Operator):
	bl_idname = "import_scene.biohazard"
	bl_label = "Import Biohazard models"

	filepath = StringProperty(subtype='FILE_PATH')
	format = EnumProperty(
		name="Format",
		description="Which model format to load",
		items=[("bio1", "Biohazard .EMD", ""), ("bio3", "Biohazard 3 .PLD", "")])
	verbose = BoolProperty(
		name="Verbose",
		description="Spews debugging info to console",
		default=True)
		
	def execute(self, context):
		val = format
		if "bio1" == val:
			from . import emd
			imp = emd.Import (self, context)
		else:
			from . import bio3
			imp = bio3.Import (self, context)
			
		print (val)
			
		if imp.main () != 0:
			def draw (window, ctx):
				window.layout.label ("See console for more info")
			bpy.context.window_manager.popup_menu (draw, title="ERROR")
		else:
			def draw (window, ctx):
				window.layout.label ("Import OK")
			bpy.context.window_manager.popup_menu (draw, title="SUCCESS")			
		return {'FINISHED'}

	def invoke(self, context, event):
		context.window_manager.fileselect_add(self)
		return {'RUNNING_MODAL'}


def menu_func(self, context):
	self.layout.operator(ImportBiohazard.bl_idname, text="Biohazard models (.emd/.pld)")


def register():
	bpy.utils.register_module(__name__)
	bpy.types.INFO_MT_file_import.append(menu_func)


def unregister():
	bpy.utils.unregister_module(__name__)
	bpy.types.INFO_MT_file_import.remove(menu_func)


if __name__ == "__main__":
	register()
