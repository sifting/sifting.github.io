#TODO: Actually use the imported normals

import os
import bpy
import math

from mathutils import *
from struct import unpack
from collections import namedtuple

Mesh = namedtuple ('Mesh', 'verts, normals, tris')

class Import:
	def __init__ (self, config, context):
		self.cfg = config
		self.ctx = context
	
	def trace (self, text):
		if self.cfg.verbose is True:
			print (text)

	def main (self):
		SCALE = 0x800
		print (self.cfg.filepath)
		f = open (self.cfg.filepath, "rb")
		#Read the footer for chunk offsets
		#TODO: Bounds check these
		f.seek (-4*4, os.SEEK_END)
		offsets = unpack ("<4I", f.read (4*4))
		self.trace ("OFFSETS: {0}".format (offsets))
		#Read the hierarchy
		f.seek (offsets[0], os.SEEK_SET)
		hh = unpack ("<4H", f.read (4*2))
		self.trace ("HIERARCHY HEADER: {0}".format (hh))
		#Read pose
		pose = []
		for i in range (hh[2]):
			pose.append (unpack ("<3h", f.read (3*2)))
		self.trace ("POSE: {0}".format (pose))
		#Read nodes
		nodes = []
		f.seek (offsets[0] + hh[0], os.SEEK_SET)
		for i in range (hh[2]):
			d = unpack ("<2H", f.read (2*2))
			links = []
			save = f.tell ()
			f.seek (offsets[0] + hh[0] + d[1], os.SEEK_SET)
			for j in range (d[0]):
				links.append (unpack ("<B", f.read (1))[0])
			nodes.append (links)
			f.seek (save, os.SEEK_SET)
		self.trace ("NODES: {0}".format (nodes))
		#Read object ids
		objs = []
		for i in range (hh[2]):
			objs.append (unpack ("<B", f.read (1)))
		self.trace ("OBJECTS: {0}".format (objs))
		#Read animation frames
		frames = []
		size = hh[3]
		start = offsets[0] + hh[1]
		end = offsets[1] - start 
		f.seek (start, os.SEEK_SET)
		self.trace ("START {0} END {1}".format (start, end))
		while size < end:
			angles = []
			save = f.tell ()
			#Read out the header data
			header = unpack ("<3h3h", f.read (3*2 + 3*2))
			#Read out the angles for each object
			for i in range (hh[2]):
				angles.append (unpack ("<3h", f.read (3*2)))
			#Append it to the frame list
			frames.append ((header, angles))
			f.seek (save + size, os.SEEK_SET)
			end -= size
		self.trace ("END: {0}".format (end))
		#Read meshes
		meshes = []
		f.seek (offsets[2], os.SEEK_SET)
		oh = unpack ("<3L", f.read (3*4))
		self.trace ("OBJECT HEADER: {0}".format (oh))
		for i in range (oh[2]):
			mh = unpack ("<7L", f.read (7*4))
			save = f.tell ()
			#Read in vertices
			verts = []
			f.seek (offsets[2] + 3*4 + mh[0], os.SEEK_SET)
			for j in range (mh[1]):
				verts.append (unpack ("<4h", f.read (4*2)))
			#Read in normals
			normals = []
			f.seek (offsets[2] + 3*4 + mh[2], os.SEEK_SET)
			for j in range (mh[3]):
				normals.append (unpack ("<4h", f.read (4*2)))
			#Read in triangles
			tris = []
			f.seek (offsets[2] + 3*4 + mh[4], os.SEEK_SET)
			for j in range (mh[5]):
				tris.append (unpack ("<L2BH2BH2BH6H", f.read (28)))
			#Assemble the mesh object and append it to the list
			meshes.append (Mesh (verts, normals, tris))
			#Restore previous position
			f.seek (save, os.SEEK_SET)
		#Copy out raw TIM image data
		f.seek (0, os.SEEK_END)
		end = f.tell ()
		f.seek (offsets[3], os.SEEK_SET)
		td = f.read (end - offsets[3])
		#Release file handle
		f.close ()
		#Decode TIM image and create material
		image = tim.decode (td)
		
		tex = bpy.data.textures.new ("TIMTEX", type = "IMAGE")
		tex.image = image
		tex.use_alpha = True
		
		mat = bpy.data.materials.new ("BASE")
		slot = mat.texture_slots.add ()
		slot.texture_coords = 'UV'
		slot.texture = tex
		#Assemble objects
		count = 0
		model = []
		for m in meshes:
			#Build normal list. Normals are stored as 1.12 fixed
			normals = []
			for n in m.normals:
				normals.append ([n[0]/0x1000, n[1]/0x1000, n[2]/0x1000])
			#Build vertex list. Verts are stored with some arbitrary scale
			verts = []
			for v in m.verts:
				verts.append ([v[0]/SCALE, v[1]/SCALE, v[2]/SCALE])
			#Build face list. Only triangles are used.
			faces = []
			for t in m.tris:
				faces.append ([t[-1], t[-3], t[-5]])
			#Create the mesh
			bm = bpy.data.meshes.new ("Mesh_{0}".format (count))
			bm.from_pydata (verts, [], faces)
			#Create UV map
			uk = 0xff
			bm.uv_textures.new ()
			for i in range (len (bm.polygons)):
				p = bm.polygons[i]
				t = m.tris[i]
				#Pages are 128x256... there are two of them
				if t[6] <= 128: ofs = 0.0
				else: ofs = 0.5
				uv = bm.uv_layers.active.data
				uv[p.loop_start + 2].uv = (ofs + t[1]/uk, 1 - t[2]/uk)
				uv[p.loop_start + 1].uv = (ofs + t[4]/uk, 1 - t[5]/uk)
				uv[p.loop_start + 0].uv = (ofs + t[7]/uk, 1 - t[8]/uk)
			bm.materials.append (mat)
			#Bind the mesh to an new object and link it to the scene
			ob = bpy.data.objects.new ("Object_{0}".format (count), bm)
			bpy.context.scene.objects.link (ob)
			model.append (ob)
			#Bump count for next mesh
			count += 1
		#Parent objects together
		objects = bpy.data.objects
		for i in range (len (nodes)):
			parent = objects["Object_{0}".format (i)]
			for ch in nodes[i]:
				child = objects["Object_{0}".format (ch)]
				child.parent = parent
		#Position the objects relative to each other
		for i in range (len (pose)):
			ob = objects["Object_{0}".format (i)]
			p = pose[i]
			ob.location.x = p[0]/SCALE
			ob.location.y = p[1]/SCALE
			ob.location.z = p[2]/SCALE
		#Add in the animation
		frame_num = 0
		for frame in frames:
			bpy.context.scene.frame_set (frame_num)
			for i in range (len (frame[1])):
				key = frame[1][i]
				ob = objects["Object_{0}".format (i)]
				local = Euler ((math.pi*key[0]/SCALE, math.pi*key[1]/SCALE, math.pi*key[2]/SCALE))
				if ob.parent is None:
					local.x -= math.radians (90)
					ob.location.x = frame[0][0]/SCALE
					ob.location.y = frame[0][1]/SCALE
					ob.location.z = frame[0][2]/SCALE
					#Rotate offsets into a blender friendly position
					tmp = ob.location
					ob.location = Euler ((-90, 0, 0)).to_matrix ()*tmp
					ob.keyframe_insert (data_path="location")
				ob.rotation_mode = 'ZYX'
				ob.rotation_euler = local
				ob.keyframe_insert (data_path="rotation_euler")
			frame_num += 1
		#Reset frame position back to start
		bpy.context.scene.frame_set (0)
		return 0
		