

import os
import bpy
import math

from mathutils import *
from struct import unpack
from collections import namedtuple

from . import tim

Mesh = namedtuple ('Mesh', 'verts, normals, tris, quads')

class Import:
	def __init__ (self, config, context):
		self.cfg = config
		self.ctx = context
	
	def trace (self, text):
		if self.cfg.verbose is True:
			print (text)

	def main (self):		
		SCALE = 0x800
		f = open (self.cfg.filepath, "rb")
		#Read chunk list
		chunks = []
		hl = unpack ("<2L", f.read (2*4))
		self.trace ("HL: {0}".format (hl))
		f.seek (hl[0], os.SEEK_SET)
		for i in range (hl[1]):
			chunks.append (unpack ("<L", f.read (4))[0])
		#Sanity check
		self.trace ("CHUNKS: {0}".format (chunks))
		if len (chunks) != 5:
			raise InputError ("MALFORMED: PLD must have 5 chunks")
		#Read the hierarchy data
		f.seek (chunks[1], os.SEEK_SET)
		hh = unpack ("<4H", f.read (4*2))
		self.trace ("HIERARCHY: {0}".format (hh))
		f.seek (chunks[1] + hh[0], os.SEEK_SET)
		#Read the local offsets
		offsets = []
		for i in range (hh[2]):
			vec = unpack ("<3h", f.read (3*2))
			offsets.append ((vec[0], vec[1], vec[2]))
		self.trace ("OFFSETS: {0}".format (offsets))
		#Read nodes
		nodes = []
		f.seek (chunks[1] + hh[0], os.SEEK_SET)
		for i in range (hh[2]):
			links = []
			d = unpack ("<2H", f.read (2*2))
			print (d)
			#Jump to read the children IDs
			save = f.tell ()
			f.seek (chunks[1] + hh[0] + d[1], os.SEEK_SET)
			for j in range (d[0]):
				links.append (unpack ("<B", f.read (1))[0])
			nodes.append (links)
			#Restore previous position
			f.seek (save, os.SEEK_SET)
		self.trace ("NODES: {0}".format (nodes))
		#Read frames
		frames = []
		start = chunks[1] + hh[1]
		end = chunks[2]
		size = hh[3]
		length = end - start
		while size < length:
			angles = []
			head = unpack ("<4h", f.read (4*2))
			stream = unpack ("<17L", f.read (17*4))
			bit = 32
			for i in range (hh[2]):
				def pull ():
					nonlocal stream, bit
					x = 0
					if 0 == bit:
						stream = stream[1:]
						bit = 32
					elif bit < 12:
						rem = 12 - bit
						part = stream[0]&((1<<bit)-1)
						stream = stream[1:]
						x = ((stream[0]&((1<<rem)-1))<<bit)|part
						bit = 32 - rem
					else:
						x = stream[0]&0xfff
						bit -= 12
					return x
				angles.append ((pull (), pull (), pull ()))
			frames.append ((head, angles))
			length -= size
		#Read meshes
		meshes = []
		f.seek (chunks[2], os.SEEK_SET)
		mh = unpack ("<2L", f.read (2*4))
		start = f.tell ()
		count = 0
		for i in range (mh[1]):
			oh = unpack ("<12H", f.read (12*2))
			print (oh)
			save = f.tell ()
			#HACK: Number of quads is actually a byte
			nquad = oh[-1]
			if nquad >= 256:
				nquad = 0
			#HACK: ntris can be set to offsets for some reason, when 0?
			ntris = oh[-2]
			if ntris == oh[6] and ntris == oh[8]:
				ntris = 0
			#Read vertices
			verts = []
			f.seek (start + oh[0], os.SEEK_SET)
			for i in range (oh[4]):
				verts.append (unpack ("<4h", f.read (4*2)))
			#Read tris
			tris = []
			f.seek (start + oh[6])
			for j in range (ntris):
				tris.append (unpack ("<4B4B4B", f.read (12)))
				#if count < 2: print (tris[-1])
			#Read quads
			quads = []
			f.seek (start + oh[8])
			for j in range (nquad):
				quads.append (unpack ("<4B4B4B4B", f.read (16)))
				#if count < 2: print (quads[-1])
			#Put everything together
			meshes.append (Mesh (verts, [], tris, quads))
			#Restore position
			f.seek (save, os.SEEK_SET)
			count += 1
		#Copy out raw TIM image data
		f.seek (0, os.SEEK_END)
		end = f.tell ()
		f.seek (chunks[4], os.SEEK_SET)
		td = f.read (end - chunks[4])
		#Release the stream
		f.close ()
		#Decode TIM image and create material
		image = tim.decode (td)
		
		tex = bpy.data.textures.new ("TIMTEX", type = "IMAGE")
		tex.image = image
		tex.use_alpha = True
		
		mat = bpy.data.materials.new ("BASE")
		slot = mat.texture_slots.add ()
		slot.texture_coords = 'UV'
		slot.texture = tex
		#Assemble objects
		count = 0
		model = []
		for m in meshes:
			#Build normal list. Normals are stored as 1.12 fixed
			normals = []
			for n in m.normals:
				normals.append ([n[0]/0x1000, n[1]/0x1000, n[2]/0x1000])
			#Build vertex list. Verts are stored with some arbitrary scale
			verts = []
			for v in m.verts:
				verts.append ([v[0]/SCALE, v[1]/SCALE, v[2]/SCALE])
			#Build face list.
			faces = []
			for t in m.tris:
				faces.append ([t[-5], t[-2], t[-1]])
			for q in m.quads:
				faces.append ([q[-1], q[-2], q[-6], q[-5]])
			#Create the mesh
			bm = bpy.data.meshes.new ("Mesh_{0}".format (count))
			bm.from_pydata (verts, [], faces)
			#Create UV map
			uk = 3*128 - 1
			bm.uv_textures.new ()
			for i in range (len (m.tris)):
				p = bm.polygons[i]
				t = m.tris[i]
				uv = bm.uv_layers.active.data
				ofs = t[2]/192
				uv[p.loop_start + 0].uv = (ofs + t[0]/uk, 1 - t[1]/255)
				uv[p.loop_start + 1].uv = (ofs + t[4]/uk, 1 - t[5]/255)
				uv[p.loop_start + 2].uv = (ofs + t[8]/uk, 1 - t[9]/255)
			#UV map quads
			offset = len (m.tris)
			for i in range (len (m.quads)):
				p = bm.polygons[offset + i]
				f = m.quads[i]
				uv = bm.uv_layers.active.data
				ofs = t[2]/192
				uv[p.loop_start + 0].uv = (ofs + f[ 0]/uk, 1 - f[ 1]/255)
				uv[p.loop_start + 1].uv = (ofs + f[ 4]/uk, 1 - f[ 5]/255)
				uv[p.loop_start + 3].uv = (ofs + f[12]/uk, 1 - f[13]/255)
				uv[p.loop_start + 2].uv = (ofs + f[ 8]/uk, 1 - f[ 9]/255)
			bm.materials.append (mat)
			#Bind the mesh to an new object and link it to the scene
			ob = bpy.data.objects.new ("Object_{0}".format (count), bm)
			bpy.context.scene.objects.link (ob)
			model.append (ob)
			#Bump count for next mesh
			count += 1
		#Parent objects together
		objects = bpy.data.objects
		for i in range (len (nodes)):
			parent = objects["Object_{0}".format (i)]
			for ch in nodes[i]:
				child = objects["Object_{0}".format (ch)]
				child.parent = parent
		#Position the objects relative to each other
		for i in range (len (offsets)):
			ob = objects["Object_{0}".format (i)]
			ofs = offsets[i]
			#ob.location.x = ofs[0]/SCALE
			#ob.location.y = ofs[1]/SCALE
			#ob.location.z = ofs[2]/SCALE
		#Add in the animation
		frame_num = 0
		for frame in frames:
			bpy.context.scene.frame_set (frame_num)
			for i in range (len (frame[1])):
				key = frame[1][i]
				ob = objects["Object_{0}".format (i)]
				local = Euler ((math.pi*key[0]/SCALE, math.pi*key[1]/SCALE, math.pi*key[2]/SCALE))
				#if ob.parent is None:
					#local.x -= math.radians (90)
					#ob.location.x = frame[0][0]/SCALE
					#ob.location.y = frame[0][1]/SCALE
					#ob.location.z = frame[0][2]/SCALE
					#Rotate offsets into a blender friendly position
					#tmp = ob.location
					#ob.location = Euler ((-90, 0, 0)).to_matrix ()*tmp
					#ob.keyframe_insert (data_path="location")
				#ob.rotation_mode = 'ZYX'
				#ob.rotation_euler = local
				#ob.keyframe_insert (data_path="rotation_euler")
			frame_num += 1
		#Reset frame position back to start
		bpy.context.scene.frame_set (0)
		return 0